package com.java.controller;

import java.util.Map;

public abstract class Controller {

	public abstract Map<String, Object> execute(Map<String, Object> paramMap);

}
